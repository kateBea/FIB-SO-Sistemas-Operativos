#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

#define CHUNK   2

/*print str to std error and exit program*/
void error_and_exit(const char* str, int ex_code)
{
    perror(str); exit(ex_code);
}

/*program usage*/
void usage(void)
{
    char buffer[128];
    strcpy(buffer, "usage: insertax2 [OFFSET] [FILE] ... OFFSET in [0, filse_size)\n");
    write (STDOUT_FILENO, buffer, strlen(buffer));
    strcpy(buffer, "insert byte X at position indicated by OFFSET\n");
    write (STDOUT_FILENO, buffer, strlen(buffer));
    exit(EXIT_SUCCESS);
}

/*shift content from fileHandle towards the end*/
/*fileHandle fd must have read and write permisions*/
void shift(int offset, const char* file_name)
{
    int fileHandle = open(file_name, O_RDWR, 0);
    if (fileHandle < 0) 
        error_and_exit("__open__ error syscall in fuction shift", -1);
    off_t CURRENT_END = lseek(fileHandle, 0, SEEK_END);
    char buffer[CHUNK]; int ret; 
    int counter = 0;
    bool fits_on_buffer = (CURRENT_END-offset) <= CHUNK;
    if (fits_on_buffer)  lseek(fileHandle, offset, SEEK_SET);
    else                lseek(fileHandle, CURRENT_END-CHUNK, SEEK_SET);

    ret = read(fileHandle, buffer, sizeof(buffer));

    while ((ret > 0) && (counter < (CURRENT_END - offset)))
    {   
        counter = counter + CHUNK;
        off_t temp;
        //avoid pointer beyond characters we must shift
        if (counter > CURRENT_END-offset)   temp = offset+1;
        else                                temp = CURRENT_END-counter+2;

        lseek(fileHandle, temp, SEEK_SET);
        ret = write(fileHandle, buffer, ret);
        lseek(fileHandle, CURRENT_END-counter-CHUNK+1, SEEK_SET);
        ret = read(fileHandle, buffer, sizeof(buffer));
    }
    close (fileHandle);
}

int main(int argc, char **argv)
{
    char buffer[128];
    if (argc != 3) usage();
    int fileHandle = open(argv[2], O_WRONLY, 0);
    if (fileHandle < 0) 
        error_and_exit("__open__ error syscall in main", -1);

    int OFFSET = atoi(argv[1]);
    off_t UPPER_BOUND = lseek(fileHandle, 0, SEEK_END);
    
    if (! (OFFSET > -1 && OFFSET < UPPER_BOUND))
    {
        strcpy(buffer, "OFFSET not valid\n");
        write (STDOUT_FILENO, buffer, strlen(buffer));
        exit(EXIT_SUCCESS);
    }
    
    shift(OFFSET, argv[2]);
    lseek(fileHandle, OFFSET, SEEK_SET);
    write(fileHandle, "X", 1);

//FOR DEBUG PURPOSES
#ifdef _DEBUG
    //cat the modified file
    pid_t pid = fork();
    if (pid < 0) error_and_exit("__fork__ error syscall", -1);
    if (pid == 0)
    {
        execlp("cat", "cat", argv[2], (char*)NULL);
        error_and_exit("__execlp__ error syscall", -1);
    }
    
    waitpid(-1, NULL, 0);
#endif

    return EXIT_SUCCESS;
}